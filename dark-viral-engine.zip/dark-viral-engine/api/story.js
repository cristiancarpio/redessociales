const { storyPrompt, callClaude, handleCors } = require('./_prompts');

module.exports = async (req, res) => {
  if (handleCors(req, res)) return;
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  const apiKey = req.headers['x-api-key'];
  if (!apiKey) return res.status(401).json({ error: 'API key required' });

  try {
    const { category, tone, length, keyword } = req.body;
    const result = await callClaude(apiKey, storyPrompt({ category, tone, length, keyword }), true);
    return res.status(200).json(result);
  } catch (err) {
    console.error('story error:', err.message);
    return res.status(500).json({ error: err.message });
  }
};
