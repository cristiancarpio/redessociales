'use strict';

const SYSTEM_BASE = `You are a master dark storyteller and viral content strategist specializing in horror, true crime, mystery, and paranormal content for Facebook, TikTok, and YouTube. You have 10+ years of experience creating viral content with millions of engagements. Your content is gripping, emotionally powerful, and designed to stop the scroll and drive comments, shares, and saves. Never add disclaimers unless absolutely necessary.`;

function storyPrompt({ category, tone, length, keyword }) {
  const kw = keyword ? `Incorporate this keyword/theme: "${keyword}".` : '';
  return {
    system: SYSTEM_BASE,
    user: `Generate a viral ${category} story.
Tone: ${tone}
Length: ${length}
${kw}

Respond in EXACT JSON (no markdown, raw JSON only):
{"title":"shocking curiosity-driven title","hook":"2-3 sentence emotional hook creating instant tension","story":"full story ending with:\\n\\n💬 If you want part 2, comment CONTINUE below. Follow for more dark stories every day."}`
  };
}

function scriptPrompt({ platform, duration, topic, category }) {
  const t = topic ? `Topic: "${topic}"` : `Category: ${category}`;
  return {
    system: SYSTEM_BASE,
    user: `Generate a short video script for ${platform}.
${t}
Duration: ${duration}

Respond in EXACT JSON (no markdown):
{"hook":"first 3 seconds - shocking and impossible to ignore","script":"full narration with [PAUSE] [SLOW] [WHISPER] [LOUD] cues. Hook -> Build -> Twist -> CTA","scenes":"SCENE 1: description\\nSCENE 2: description\\netc"}`
  };
}

function ideasPrompt({ type, count }) {
  return {
    system: SYSTEM_BASE,
    user: `Generate exactly ${count} viral content ideas for horror/mystery social media.
Focus: ${type}
Format each as: N. [CATEGORY] Title — one-sentence hook
Categories: [SERIAL KILLER] [TRUE CRIME] [PARANORMAL] [UNSOLVED] [DARK HISTORY] [CREEPY LOCATION] [DISAPPEARANCE] [URBAN LEGEND]
Be specific with real names/dates/places. No intro, just the list.`
  };
}

function imagesPrompt({ style, subject, count }) {
  const s = subject ? `Include: "${subject}"` : '';
  return {
    system: SYSTEM_BASE,
    user: `Generate ${count} detailed AI image prompts for horror/dark mystery content.
Style: ${style}
${s}
Number each prompt. Each: 50-80 words, cinematic, includes camera angle + lighting + mood + color grade.
End each with: --ar 9:16 --style raw
No intro. Just numbered prompts.`
  };
}

function hashtagsPrompt({ platform, topic }) {
  const t = topic ? `Topic: "${topic}"` : 'Topic: horror and mystery content';
  return {
    system: SYSTEM_BASE,
    user: `Generate optimized hashtags for ${platform}.
${t}
Format:
TRENDING (1M+ posts):
#tag1 #tag2 ...

NICHE (100K-1M posts):  
#tag1 #tag2 ...

ENGAGEMENT (<100K posts):
#tag1 #tag2 ...

Total 25-30 tags for TikTok/IG, 10-15 for Facebook/YouTube. No explanations.`
  };
}

function rewritePrompt({ text, style }) {
  return {
    system: SYSTEM_BASE,
    user: `Rewrite this story as a viral ${style} optimized for Facebook engagement.

ORIGINAL:
${text}

Rules: powerful opening hook, short paragraphs (1-3 sentences), mobile-optimized line breaks, escalating tension, end with: "💬 Comment CONTINUE for Part 2"
Respond with ONLY the rewritten story.`
  };
}

function analyzePrompt({ text }) {
  return {
    system: SYSTEM_BASE,
    user: `Analyze this viral post and provide strategic insights.

POST:
${text}

Respond in EXACT JSON (no markdown):
{"analysis":"Why it went viral:\\n• Emotional triggers:\\n• Engagement tactics:\\n• Psychological hooks:\\n• Structure:","similar":"A fresh original content idea using this post's formula (write as ready-to-post Facebook post)","improved":"An improved version - better hook, better pacing, stronger ending"}`
  };
}

function multiplyPrompt({ text }) {
  return {
    system: SYSTEM_BASE,
    user: `Create a complete content package from this story/idea.

INPUT:
${text}

Respond in EXACT JSON (no markdown):
{"facebook":"viral FB post 300-500 words with hook + story + 💬 Comment CONTINUE CTA","reel":"60-second Facebook Reel script with [PACING CUES]. Hook(0-3s)->Build(3-45s)->Twist(45-55s)->CTA(55-60s)","short":"30-second TikTok/Shorts script. Punchy. Include [VISUAL CUE] inline.","images":"3 cinematic AI image prompts for this story. Each 50+ words, 9:16 vertical, Midjourney-ready.","hashtags":"25 optimized hashtags - mix trending + niche + engagement. Ready to paste."}`
  };
}

function dashboardPrompt({ section }) {
  const prompts = {
    storyIdeas: { system: SYSTEM_BASE, user: `Generate 3 viral story ideas for today's horror/mystery content.\nFormat: numbered list, one per line.\nEach: [CATEGORY] Shocking title — one-sentence hook.\nReal names, places, dates. No intro. Just 3 ideas.` },
    scriptHooks: { system: SYSTEM_BASE, user: `Generate 2 scroll-stopping hooks for horror short video scripts.\nHOOK 1: [1-2 sentences, shocking, for first 3 seconds]\nHOOK 2: [1-2 sentences, shocking, for first 3 seconds]\nMake them impossible to ignore.` },
    contentIdeas: { system: SYSTEM_BASE, user: `Generate 10 viral content ideas for a horror/mystery/true crime Facebook page.\nNumbered list. Each: [TAG] Brief punchy idea.\nTags: [SERIAL KILLER] [PARANORMAL] [UNSOLVED] [DARK HISTORY] [URBAN LEGEND] [DISAPPEARANCE]\nSpecific. Real cases. Just the list.` },
    imagePrompts: { system: SYSTEM_BASE, user: `Generate 2 AI image prompts for dark horror content.\nPROMPT 1: [full cinematic prompt, 50+ words, 9:16]\nPROMPT 2: [full cinematic prompt, 50+ words, 9:16]\nDark cinematic horror, atmospheric, high detail.` },
    hashtags: { system: SYSTEM_BASE, user: `Today's hashtag pack for a horror/mystery Facebook page.\nBROAD: [10 high-reach tags]\nNICHE: [10 horror/crime specific tags]\nENGAGEMENT: [5 community tags]\nReady to copy. No explanations.` }
  };
  return prompts[section] || { system: SYSTEM_BASE, user: 'Generate horror content ideas.' };
}

async function callClaude(apiKey, { system, user }, isJSON = false, maxTokens = 2048) {
  const response = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': apiKey,
      'anthropic-version': '2023-06-01',
    },
    body: JSON.stringify({
      model: 'claude-sonnet-4-20250514',
      max_tokens: maxTokens,
      system,
      messages: [{ role: 'user', content: user }],
    }),
  });

  if (!response.ok) {
    const err = await response.json().catch(() => ({}));
    throw new Error(err.error?.message || `Anthropic API error ${response.status}`);
  }

  const data = await response.json();
  const text = data.content?.[0]?.text || '';

  if (isJSON) {
    const clean = text.replace(/```json\s*/gi, '').replace(/```\s*/g, '').trim();
    return JSON.parse(clean);
  }
  return text;
}

function corsHeaders() {
  return {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, x-api-key',
    'Content-Type': 'application/json',
  };
}

function handleCors(req, res) {
  const h = corsHeaders();
  if (req.method === 'OPTIONS') {
    Object.entries(h).forEach(([k, v]) => res.setHeader(k, v));
    res.status(204).end();
    return true;
  }
  Object.entries(h).forEach(([k, v]) => res.setHeader(k, v));
  return false;
}

module.exports = {
  storyPrompt, scriptPrompt, ideasPrompt, imagesPrompt,
  hashtagsPrompt, rewritePrompt, analyzePrompt, multiplyPrompt,
  dashboardPrompt, callClaude, corsHeaders, handleCors,
};
