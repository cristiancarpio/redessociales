const { ideasPrompt, callClaude, handleCors } = require('./_prompts');

module.exports = async (req, res) => {
  if (handleCors(req, res)) return;
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  const apiKey = req.headers['x-api-key'];
  if (!apiKey) return res.status(401).json({ error: 'API key required' });

  try {
    const body = req.body;
    const prompt = ideasPrompt(body);
    const isJson = ['analyze'].includes('ideas');
    const result = await callClaude(apiKey, prompt, isJson);
    const key = { ideas: 'ideas', images: 'prompts', hashtags: 'hashtags', rewrite: 'rewritten', analyze: null, dashboard: 'content' }['ideas'];
    if (key) return res.status(200).json({ [key]: result });
    return res.status(200).json(result);
  } catch (err) {
    console.error('ideas error:', err.message);
    return res.status(500).json({ error: err.message });
  }
};
