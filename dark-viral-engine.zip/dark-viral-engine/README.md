# ☠ Dark Viral Content Engine

> AI-powered content production system for horror, mystery, true crime & dark storytelling.

---

## 📐 System Architecture

```
┌─────────────────────────────────────────┐
│         USER  (Mobile PWA)              │
│         Chrome / Safari                 │
└────────────────┬────────────────────────┘
                 │ HTTPS
┌────────────────▼────────────────────────┐
│         VERCEL EDGE NETWORK             │
│  /public/*  ──► Static Hosting          │
│  /api/*.js  ──► Serverless Functions    │
│                 (30s timeout, free tier)│
└────────────────┬────────────────────────┘
                 │ User's own API key
┌────────────────▼────────────────────────┐
│    ANTHROPIC API  claude-sonnet-4       │
│    ~$0.30-0.60 / 20 pieces of content   │
└─────────────────────────────────────────┘
```

**No database. No backend cost. Just Vercel free tier + your Anthropic key.**

---

## 📁 Folder Structure

```
dark-viral-engine/
├── public/                  ← Static frontend
│   ├── index.html           ← PWA shell, all 6 tabs
│   ├── style.css            ← Gothic horror UI
│   ├── app.js               ← All frontend logic
│   ├── sw.js                ← Service Worker (offline PWA)
│   ├── manifest.json        ← PWA config
│   └── icons/               ← App icons
│
├── api/                     ← Serverless functions
│   ├── _prompts.js          ← All AI prompts + shared utils
│   ├── story.js             ← POST /api/story
│   ├── script.js            ← POST /api/script
│   ├── ideas.js             ← POST /api/ideas
│   ├── images.js            ← POST /api/images
│   ├── hashtags.js          ← POST /api/hashtags
│   ├── rewrite.js           ← POST /api/rewrite
│   ├── analyze.js           ← POST /api/analyze
│   ├── multiply.js          ← POST /api/multiply
│   └── dashboard.js         ← POST /api/dashboard
│
├── vercel.json              ← Routing + function config
├── package.json
└── README.md
```

---

## 🚀 Deploy to Vercel (5 minutes)

### 1. Install Vercel CLI
```bash
npm install -g vercel
vercel login
```

### 2. Deploy
```bash
cd dark-viral-engine
vercel --prod
```

That's it. Vercel detects `vercel.json`, deploys `/public` as static and `/api` as serverless functions.  
Your URL: `https://dark-viral-engine-xxx.vercel.app`

### 3. Test locally first
```bash
npm install
vercel dev
# → http://localhost:3000
```

---

## 📱 Install as Mobile App (PWA)

**Android (Chrome):**
1. Open your Vercel URL in Chrome
2. Menu (⋮) → "Add to Home screen" → Add
3. Full-screen app icon on home screen ✓

**iOS (Safari):**
1. Open URL in **Safari** (not Chrome)
2. Share button (⬆) → "Add to Home Screen" → Add
3. Opens in full-screen mode ✓

---

## 🔑 API Key

First launch asks for your Anthropic API key (starts with `sk-ant-`).  
Get one at [console.anthropic.com](https://console.anthropic.com)  
Key saved in browser localStorage — one-time entry per device.

**Cost:** ~$0.30–0.60/day generating 20 pieces of content

---

## 🛠 API Endpoints

| Endpoint | Body | Returns |
|---|---|---|
| `POST /api/story` | `{category, tone, length, keyword}` | `{title, hook, story}` |
| `POST /api/script` | `{platform, duration, topic, category}` | `{hook, script, scenes}` |
| `POST /api/ideas` | `{type, count}` | `{ideas}` |
| `POST /api/images` | `{style, subject, count}` | `{prompts}` |
| `POST /api/hashtags` | `{platform, topic}` | `{hashtags}` |
| `POST /api/rewrite` | `{text, style}` | `{rewritten}` |
| `POST /api/analyze` | `{text}` | `{analysis, similar, improved}` |
| `POST /api/multiply` | `{text}` | `{facebook, reel, short, images, hashtags}` |
| `POST /api/dashboard` | `{section}` | `{content}` |

All endpoints require header: `x-api-key: sk-ant-...`

---

## 🔮 Future Growth Features

- **Trend Scanner** — Auto-pull trending topics from Reddit/Google Trends
- **Auto-Scheduler** — Connect Facebook Graph API, post on schedule
- **Bulk Generator** — 20 stories in one click, export as ZIP
- **Series Engine** — Auto-generate Part 2, 3, 4 continuations
- **Content History** — Save all generated content (add Supabase)
- **Thumbnail Generator** — Auto-create thumbnails via DALL-E API
- **Analytics Dashboard** — Track which formats drive most engagement
- **Multi-page Manager** — Different voice/style per Facebook page
- **Voice Preview** — Text-to-speech preview of your scripts
- **Competitor Analyzer** — Input any page URL, get their formula

---

*Generate fast. Post more. Grow the darkness.* ☠
