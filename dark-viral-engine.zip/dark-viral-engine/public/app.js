/* ═══════════════════════════════════════════════════
   DARK VIRAL CONTENT ENGINE — Frontend JS
   ═══════════════════════════════════════════════════ */

'use strict';

// ── State ──────────────────────────────────────────
const state = {
  activeTab:    'dashboard',
  activeSubtab: 'images',
  generating:   false,
};

// ── Init ───────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  initTabs();
  initSubtabs();
  initCategoryButtons();
  initGenerators();
  initMultiplier();
  initDashboardRefresh();
  registerSW();
});

// ── Service Worker ─────────────────────────────────
function registerSW() {
  if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
      navigator.serviceWorker.register('/sw.js').catch(() => {});
    });
  }
}

// ── Tab Navigation ─────────────────────────────────
function initTabs() {
  const nav = document.getElementById('mainNav');
  nav.addEventListener('click', e => {
    const btn = e.target.closest('.nav-btn');
    if (!btn) return;
    const tab = btn.dataset.tab;
    document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
    document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
    btn.classList.add('active');
    document.getElementById('tab-' + tab)?.classList.add('active');
    state.activeTab = tab;
    window.scrollTo({ top: 0, behavior: 'smooth' });
  });
}

// ── Subtab Navigation ──────────────────────────────
function initSubtabs() {
  document.querySelectorAll('.subtab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const subtab = btn.dataset.subtab;
      const parent = btn.closest('.tab-panel');
      parent.querySelectorAll('.subtab-btn').forEach(b => b.classList.remove('active'));
      parent.querySelectorAll('.subtab-panel').forEach(p => p.classList.remove('active'));
      btn.classList.add('active');
      document.getElementById('subtab-' + subtab)?.classList.add('active');
      state.activeSubtab = subtab;
    });
  });
}

// ── Category / Toggle Buttons ──────────────────────
function initCategoryButtons() {
  document.querySelectorAll('.cat-grid').forEach(grid => {
    grid.addEventListener('click', e => {
      const btn = e.target.closest('.cat-btn');
      if (!btn) return;
      grid.querySelectorAll('.cat-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
    });
  });
}

// ── Helpers ────────────────────────────────────────
function getActiveCat(gridId) {
  return document.querySelector(`#${gridId} .cat-btn.active`)?.dataset.value || '';
}

function val(id) {
  return document.getElementById(id)?.value || '';
}

function showLoading(msg = 'Generating content...') {
  const overlay = document.getElementById('loadingOverlay');
  document.getElementById('loadingText').textContent = msg;
  overlay.classList.add('active');
  state.generating = true;
}

function hideLoading() {
  document.getElementById('loadingOverlay').classList.remove('active');
  state.generating = false;
}

function showToast(msg, type = '') {
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.className = 'toast show ' + type;
  setTimeout(() => t.className = 'toast', 2600);
}

function showOutput(areaId, contentId, html) {
  document.getElementById(areaId).style.display = 'block';
  document.getElementById(contentId).innerHTML = html;
}

// ── API Call ────────────────────────────────────────
async function callAPI(endpoint, payload) {
  const res = await fetch(`/api/${endpoint}`, {
    method:  'POST',
    headers: { 'Content-Type': 'application/json' },
    body:    JSON.stringify(payload),
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error || `HTTP ${res.status}`);
  }
  return res.json();
}

// ── Markdown-ish Renderer ──────────────────────────
function renderContent(text) {
  // Convert basic markdown to HTML
  return text
    .replace(/^### (.+)$/gm, '<h3>$1</h3>')
    .replace(/^## (.+)$/gm, '<h3>$1</h3>')
    .replace(/^# (.+)$/gm, '<h3>$1</h3>')
    .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
    .replace(/\*(.+?)\*/g, '<em>$1</em>')
    .replace(/^[-•] (.+)$/gm, '<li>$1</li>')
    .replace(/(<li>.*<\/li>)/gs, '<ul>$1</ul>')
    .replace(/\n{2,}/g, '</p><p>')
    .replace(/^(?!<[hup])/gm, '')
    .replace(/^(.+)(?<!>)$/gm, (m, c) => c.startsWith('<') ? c : `<p>${c}</p>`)
    .trim();
}

function safeRender(text) {
  // Simple but safe render
  const lines = text.split('\n');
  let html = '';
  let inUl = false;
  for (const line of lines) {
    const trimmed = line.trim();
    if (!trimmed) { if (inUl) { html += '</ul>'; inUl = false; } html += ''; continue; }
    if (trimmed.startsWith('### ') || trimmed.startsWith('## ') || trimmed.startsWith('# ')) {
      if (inUl) { html += '</ul>'; inUl = false; }
      html += `<h3>${trimmed.replace(/^#+\s*/, '')}</h3>`;
    } else if (trimmed.startsWith('- ') || trimmed.startsWith('• ')) {
      if (!inUl) { html += '<ul>'; inUl = true; }
      html += `<li>${trimmed.slice(2).replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')}</li>`;
    } else {
      if (inUl) { html += '</ul>'; inUl = false; }
      const formatted = trimmed.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>').replace(/\*(.+?)\*/g, '<em>$1</em>');
      html += `<p>${formatted}</p>`;
    }
  }
  if (inUl) html += '</ul>';
  return html;
}

// ── Copy Output ────────────────────────────────────
function copyOutput(contentId) {
  const el = document.getElementById(contentId);
  if (!el) return;
  const text = el.innerText;
  navigator.clipboard.writeText(text)
    .then(() => showToast('✓ Copied to clipboard', 'success'))
    .catch(() => showToast('Copy failed'));
}

// ── Send to Multiplier ─────────────────────────────
function sendToMultiplier(contentId) {
  const text = document.getElementById(contentId)?.innerText || '';
  if (!text) return;
  document.getElementById('multiplierInput').value = text;
  // Switch to multiply tab
  document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
  document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
  document.querySelector('[data-tab="multiply"]').classList.add('active');
  document.getElementById('tab-multiply').classList.add('active');
  showToast('Story loaded into Multiplier', 'success');
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

// ── Story Generator ────────────────────────────────
function initGenerators() {
  // Story
  document.getElementById('generateStory').addEventListener('click', async () => {
    if (state.generating) return;
    showLoading('Crafting your dark story...');
    try {
      const data = await callAPI('generate', {
        type: 'story',
        category: getActiveCat('storyCategory'),
        tone:     val('storyTone'),
        length:   val('storyLength'),
        angle:    val('storyAngle'),
      });
      showOutput('storyOutput', 'storyOutputContent', safeRender(data.content));
    } catch (e) {
      showToast('Error: ' + e.message);
    } finally {
      hideLoading();
    }
  });

  // Script
  document.getElementById('generateScript').addEventListener('click', async () => {
    if (state.generating) return;
    showLoading('Writing your video script...');
    try {
      const data = await callAPI('generate', {
        type:     'script',
        platform: getActiveCat('scriptPlatform'),
        genre:    val('scriptGenre'),
        duration: val('scriptDuration'),
        topic:    val('scriptTopic'),
      });
      showOutput('scriptOutput', 'scriptOutputContent', safeRender(data.content));
    } catch (e) {
      showToast('Error: ' + e.message);
    } finally {
      hideLoading();
    }
  });

  // Ideas
  document.getElementById('generateIdeas').addEventListener('click', async () => {
    if (state.generating) return;
    showLoading('Generating viral ideas...');
    try {
      const data = await callAPI('generate', {
        type:     'ideas',
        filter:   val('ideasFilter'),
        platform: val('ideasPlatform'),
      });
      const ideas = data.content.split('\n').filter(l => l.trim());
      let html = '';
      let count = 0;
      for (const line of ideas) {
        const clean = line.replace(/^\d+[\.\)]\s*/, '').replace(/^[-•]\s*/, '').trim();
        if (!clean) continue;
        count++;
        html += `<div class="idea-item"><span class="idea-num">${String(count).padStart(2,'0')}</span><span class="idea-text">${clean}</span></div>`;
        if (count >= 20) break;
      }
      document.getElementById('ideasPlaceholder') && (document.getElementById('ideasPlaceholder').style.display = 'none');
      showOutput('ideasOutput', 'ideasOutputContent', html);
    } catch (e) {
      showToast('Error: ' + e.message);
    } finally {
      hideLoading();
    }
  });

  // Image Prompts
  document.getElementById('generateImages').addEventListener('click', async () => {
    if (state.generating) return;
    showLoading('Generating image prompts...');
    try {
      const data = await callAPI('generate', {
        type:    'images',
        style:   getActiveCat('imageStyle'),
        subject: val('imageSubject'),
        count:   val('imageCount'),
      });
      showOutput('imageOutput', 'imageOutputContent', safeRender(data.content));
    } catch (e) {
      showToast('Error: ' + e.message);
    } finally {
      hideLoading();
    }
  });

  // Hashtags
  document.getElementById('generateHashtags').addEventListener('click', async () => {
    if (state.generating) return;
    showLoading('Generating hashtags...');
    try {
      const data = await callAPI('generate', {
        type:     'hashtags',
        platform: getActiveCat('hashtagPlatform'),
        topic:    val('hashtagTopic'),
      });
      showOutput('hashtagOutput', 'hashtagOutputContent', safeRender(data.content));
    } catch (e) {
      showToast('Error: ' + e.message);
    } finally {
      hideLoading();
    }
  });

  // Rewriter
  document.getElementById('generateRewrite').addEventListener('click', async () => {
    if (state.generating) return;
    const input = val('rewriterInput').trim();
    if (!input) { showToast('Please paste a story first'); return; }
    showLoading('Rewriting your story...');
    try {
      const data = await callAPI('generate', {
        type:  'rewrite',
        story: input,
        goal:  val('rewriterGoal'),
      });
      showOutput('rewriterOutput', 'rewriterOutputContent', safeRender(data.content));
    } catch (e) {
      showToast('Error: ' + e.message);
    } finally {
      hideLoading();
    }
  });

  // Analyzer
  document.getElementById('generateAnalysis').addEventListener('click', async () => {
    if (state.generating) return;
    const input = val('analyzerInput').trim();
    if (!input) { showToast('Please paste a viral post first'); return; }
    showLoading('Analyzing viral mechanics...');
    try {
      const data = await callAPI('generate', {
        type: 'analyze',
        post: input,
      });
      showOutput('analyzerOutput', 'analyzerOutputContent', safeRender(data.content));
    } catch (e) {
      showToast('Error: ' + e.message);
    } finally {
      hideLoading();
    }
  });
}

// ── Content Multiplier ─────────────────────────────
function initMultiplier() {
  document.getElementById('generateMultiply').addEventListener('click', async () => {
    if (state.generating) return;
    const story = val('multiplierInput').trim();
    if (!story) { showToast('Please enter a story first'); return; }

    const selectedOutputs = Array.from(
      document.querySelectorAll('.checkbox-grid input[type="checkbox"]:checked')
    ).map(cb => cb.dataset.output);

    if (!selectedOutputs.length) { showToast('Select at least one output type'); return; }

    showLoading('Multiplying your content...');
    try {
      const data = await callAPI('generate', {
        type:    'multiply',
        story,
        outputs: selectedOutputs,
      });

      const container = document.getElementById('multiplyResults');
      container.innerHTML = '';

      const icons = {
        facebook_post: '📘',
        reel_script:   '🎬',
        short_video:   '📱',
        image_prompts: '🖼',
        hashtags:      '🏷',
      };

      const labels = {
        facebook_post: 'Facebook Post',
        reel_script:   'Reel Script',
        short_video:   'Short Video Script',
        image_prompts: 'Image Prompts',
        hashtags:      'Hashtags',
      };

      for (const [key, content] of Object.entries(data.results)) {
        const card = document.createElement('div');
        card.className = 'multiply-card';
        card.innerHTML = `
          <div class="multiply-card-header" onclick="toggleMultiplyCard(this)">
            <span class="multiply-card-title">${icons[key] || '📄'} ${labels[key] || key}</span>
            <span class="multiply-card-toggle">▶</span>
          </div>
          <div class="multiply-card-body">
            ${safeRender(content)}
            <div class="multiply-card-actions">
              <button class="btn-ghost btn-xs" onclick="copyText(this, \`${escapeBacktick(content)}\`)">Copy</button>
            </div>
          </div>
        `;
        container.appendChild(card);
        // Auto-open first card
        if (container.children.length === 1) card.classList.add('open');
      }

      document.getElementById('multiplierOutput').style.display = 'block';
      document.getElementById('multiplierOutput').scrollIntoView({ behavior: 'smooth' });
    } catch (e) {
      showToast('Error: ' + e.message);
    } finally {
      hideLoading();
    }
  });
}

function toggleMultiplyCard(header) {
  header.closest('.multiply-card').classList.toggle('open');
}

function copyText(btn, text) {
  navigator.clipboard.writeText(text)
    .then(() => showToast('✓ Copied', 'success'))
    .catch(() => showToast('Copy failed'));
}

function escapeBacktick(str) {
  return str.replace(/`/g, '\\`').replace(/\$/g, '\\$');
}

// ── Dashboard ──────────────────────────────────────
const dashLoadingMsgs = {
  ideas:    'Loading viral ideas...',
  stories:  'Loading story starters...',
  scripts:  'Loading reel scripts...',
  prompts:  'Loading image prompts...',
  hashtags: 'Loading hashtags...',
};

async function dashGenerate(type) {
  if (state.generating) return;
  showLoading(dashLoadingMsgs[type] || 'Loading...');
  try {
    const payloads = {
      ideas:   { type: 'ideas',    filter: 'all types of horror and mystery content', platform: 'Facebook', count: 10 },
      stories: { type: 'dash_stories' },
      scripts: { type: 'dash_scripts' },
      prompts: { type: 'images',   style: 'dark cinematic horror', count: '5' },
      hashtags:{ type: 'hashtags', platform: 'all platforms', topic: 'horror true crime dark stories' },
    };
    const data = await callAPI('generate', payloads[type]);
    const bodyId = `dc-${type === 'stories' ? 'stories' : type === 'scripts' ? 'scripts' : type === 'prompts' ? 'prompts' : type}-body`;
    const el = document.getElementById(bodyId);
    if (el) el.innerHTML = safeRender(data.content);
  } catch (e) {
    showToast('Error: ' + e.message);
  } finally {
    hideLoading();
  }
}

function initDashboardRefresh() {
  document.getElementById('refreshDashboard').addEventListener('click', async () => {
    for (const type of ['ideas', 'stories', 'scripts', 'prompts', 'hashtags']) {
      await dashGenerate(type);
    }
  });
}

// ── Expose globals ─────────────────────────────────
window.dashGenerate  = dashGenerate;
window.copyOutput    = copyOutput;
window.copyText      = copyText;
window.sendToMultiplier = sendToMultiplier;
window.toggleMultiplyCard = toggleMultiplyCard;
